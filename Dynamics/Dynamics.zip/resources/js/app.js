//load JQUERY
window.$ = window.jQuery = require('jquery');
window.Popper = require('popper.js');
require('bootstrap');
require('jquery');

//Preloader
require('./preloader')

//load Node Module
require('jquery.appear');
require('jquery.easing');
//require('magnific-popup');

//require('bootstrap');

//Load local files
//**require('./imagesloaded.pkgd.min');
//**require('./slick.min');
//*require('./main');
require('./scrolling-nav');
require('./ajax-contact');


//**require('isotope-layout');
//**require('@popperjs/core');
//*web*require('modernizr');
//require('slick');
//require('imagesloaded');
//require('animate.css');
