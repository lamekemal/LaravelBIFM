<footer>
    <section class="footer-area footer-dark">
<div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="footer-logo text-center">
                        <a class="mt-30" href="index.html"><img src="<?php echo e(URL::asset('images/xlo.png')); ?>" alt="Logo"></a>
                    </div> <!-- footer logo -->
                    <ul class="social text-center mt-60">
                        <li><a href="https://facebook.com/?=@bifmtec"><i class="lni lni-facebook-filled"></i></a></li>
                        <li><a href="https://www.linkedin.com/in/bifm-technologies-486b1b212"><i class="lni lni-linkedin-original"></i></a></li>
                    </ul> <!-- social -->

                    <div class="copyright text-center mt-35">
                        <?php if(auth()->guard()->guest()): ?>
                            <a class="no-underline hover:underline" href="<?php echo e(route('login')); ?>"><?php echo e(__('BIFM+')); ?></a>
                            <?php if(Route::has('register')): ?>
                                <a class="no-underline hover:underline" href="<?php echo e(route('register')); ?>"><?php echo e(__('.')); ?></a>
                            <?php endif; ?>
                        <?php else: ?>
                            <span><?php echo e(Auth::user()->name); ?></span>

                            <a href="<?php echo e(route('logout')); ?>"
                            class="no-underline hover:underline"
                            onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden">
                                <?php echo e(csrf_field()); ?>

                            </form>
                            <a class="btn btn-outline-primary btn-sm" href="/Dashboard"><?php echo e(__('Dashboard')); ?></a>
                        <?php endif; ?>
                        <p class="text">Bifmtec copyright 2021</a> </p>
                    </div> <!--  copyright -->
                </div>
            </div> <!-- row -->
</div> <!-- container -->
</section>
</footer>
<?php /**PATH D:\Projects\LaravelBIFM\Dynamics\resources\views/layouts/footer.blade.php ENDPATH**/ ?>