<?php $__env->startSection('content'); ?>

    <section id="about" class="about-area" style="margin-top: 125px">
        <h3 style="margin:25px;"> Modification d'une actualité :</h3>

        <div class="container" style="margin:25px;">
            <form class="form-group" action="/Actualite/<?php echo e($post->slug); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <input type="text" style="margin:15px;" name="title" value="<?php echo e($post->title); ?>" class="form-control">
                <textarea name="description" style="margin:15px;"
                    class="form-control"> <?php echo e($post->description); ?> </textarea>
                <button style="margin:25px;" type="submit" class="btn btn-outline-primary">Enregistrer</button>
            </form>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\LaravelBIFM\Dynamics\resources\views/news/edit.blade.php ENDPATH**/ ?>