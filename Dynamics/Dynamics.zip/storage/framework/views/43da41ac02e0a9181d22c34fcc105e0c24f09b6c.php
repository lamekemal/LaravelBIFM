<li class="nav-item"><a class="page-scroll" href="/Electricite">Electricité</a></li>
<li class="nav-item"><a class="page-scroll" href="/Climatisation">Climatisation</a></li>
<li class="nav-item">
  <div class="dropdown">
      <a class="page-scroll dropbtn" href="/Securite">Sécurité</a>
    <div class="dropdown-content" style ="margin-left: -22px;">
      <a class="dpdtx" href="/Securite/Alarme-intrusion">Alarme intrusion</a>
      <a class="dpdtx" href="/Securite/Alarme-incendie">Alarme incendie</a>
      <a class="dpdtx" href="/Securite/Video-surveillance">Video surveillance</a>
      <a class="dpdtx" href="/Securite/Control-acces">Contrôl d'accès</a>
      <a class="dpdtx" href="/Securite/Cablage-reseau">Câblage réseau</a>
    </div>
  </div>
</li>
<li class="nav-item"><a class="page-scroll" href="/Domotique">Domotique</a></li>
<li class="nav-item"><a class="page-scroll" href="/FacilityManagement">FM</a></li>
<li class="nav-item"><a class="page-scroll" href="/Actualite">Actualités</a></li>
<li class="nav-item"><a class="page-scroll" href="/#contact">Contact</a></li>
<li class="nav-item" ><a class="page-scroll" href="/BiShop">BiShop</a></li>
<?php /**PATH D:\Projects\LaravelBIFM\Dynamics\resources\views/layouts/nav_items.blade.php ENDPATH**/ ?>