<?php $__env->startSection('content'); ?>

    <section id="about" class="about-area" style="margin-top: 125px">
        <h3 style="margin:25px;"> Ajouter une actualité supplémentaire :</h3>

        <?php if($errors->any()): ?>
            <div class="container" style="margin:25px;">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item list-group-item-danger">
                            <?php echo e($error); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>

            </div>
        <?php endif; ?>
        <div class="container" style="margin:25px;">
            <form class="form-group" action="/Actualite" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="text" style="margin:15px;" name="title" placeholder="Titre de l'article" class="form-control">
                <textarea name="description" style="margin:15px;" placeholder=" Texte de l'Article"
                    class="form-control"> </textarea>
                <div class="custom-file" style="margin:15px;">
                    <input type="file" class="custom-file-input" id="customFileLang" lang="fr" name="image">
                    <label class="custom-file-label" for="customFileLang">Selectionner une image de description</label>
                </div>
                <button style="margin:25px;" type="submit" class="btn btn-outline-primary">Enregistrer</button>
            </form>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\LaravelBIFM\Dynamics\resources\views/news/nouveau.blade.php ENDPATH**/ ?>