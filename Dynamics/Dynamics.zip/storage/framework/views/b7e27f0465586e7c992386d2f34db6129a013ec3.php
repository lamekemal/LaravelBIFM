<?php $__env->startSection('title', 'Actualité'); ?>
<?php $__env->startSection('content'); ?>

    <section id="home" class="slider_area">
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img data-animation="animated zoomInUp" class="first-slide" src="<?php echo e(URL::asset('images/nws.jpg')); ?>"
                        alt="First slide">
                    <div class="container">
                        <div class="carousel-caption text-left">
                            <h1 data-animation="animated bounceInDown" style="color: #fff">Actualités</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section id="about" class="about-area">

        <?php if(session()->has('message')): ?>
            <div style="margin-top: 35px; margin: 25px">
                <ul class="list-group">
                    <li class="list-group-item list-group-item-info">
                        <?php echo e(session()->get('message')); ?>

                    </li>
                </ul>
            </div>
        <?php endif; ?>


        <?php if(Auth::check()): ?>
            <a href="/Actualite/create" class="btn btn-primary btn-lg text-uppercase"
                style="margin-top: 35px; margin:25px;">Ajouté une
                actualité</a>
        <?php endif; ?>


        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="about-image mt-70">
                            <img src="<?php echo e(URL::asset('images/' . $post->image_path)); ?>" alt="about">
                        </div> <!-- faq image -->
                    </div>
                    <div class="col">
                        <div class="faq-content mt-55">
                            <h2>
                                <?php echo e($post->title); ?>

                            </h2>
                            <span>
                                Par <span class="font-weight-bold font-italic"> <?php echo e($post->user->name); ?> de BIFM Technology
                                </span>, ajouté le <?php echo e(date('j M Y', strtotime($post->updated_at))); ?>

                            </span>
                            <p class="text-justify" style="font-size: 19px; margin-top: 15px">
                                <?php echo e($post->description); ?>

                            </p>

                            <a href="/Actualite/<?php echo e($post->slug); ?>" class="btn btn-primary btn-lg text-uppercase"
                                style="margin-top: 35px">Plus de
                                détails</a>
                            <?php if(isset(Auth::user()->id) && Auth::user()->id == $post->user_id): ?>
                                <span class="font-italic text-right float-right" style="margin: 5px">
                                    <a href="/Actualite/<?php echo e($post->slug); ?>/edit" class="btn btn-outline-info">
                                        Modifier
                                    </a>
                                </span>
                                <span class="font-italic text-right float-right" style="margin: 5px">
                                    <form class="form-group" action="/Actualite/<?php echo e($post->slug); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-outline-danger">Supprimer</button>
                                    </form>
                                </span>
                            <?php endif; ?>
                        </div>


                    </div>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\LaravelBIFM\Dynamics\resources\views/news/index.blade.php ENDPATH**/ ?>