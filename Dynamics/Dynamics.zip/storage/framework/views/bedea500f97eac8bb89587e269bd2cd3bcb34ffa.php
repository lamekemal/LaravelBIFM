<?php $__env->startSection('content'); ?>
    <section id="about" class="about-area" style="margin-top: 125px">

        <?php if(session()->has('message')): ?>
            <div style="margin-top: -5px; margin: -5px">
                <ul class="list-group">
                    <li class="list-group-item list-group-item-info">
                        <?php echo e(session()->get('message')); ?>

                    </li>
                </ul>
            </div>
        <?php endif; ?>

        <div data-xanim="glideInUp" class="container">

            <?php $__currentLoopData = $sellings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="margin-top: 5px; margin-bottom : 20px">
                    <div class="card-header">

                        <form class="form-group" action="/Selling/<?php echo e($product->slug); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="text" value="1"
                                style="max-height: 0px; max-width: 0px;padding-top: 0px;padding-bottom: 0px;padding-left: 0px;padding-right: 0px;"
                                name="status" class="form-control invisible">
                            <button type="submit" class="btn btn-outline-success float-right"
                                style="margin-right: 8px">Message traité</button>
                        </form>
                        <form class="form-group" action="/Selling/<?php echo e($product->slug); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="text" value="0"
                                style="max-height: 0px; max-width: 0px;padding-top: 0px;padding-bottom: 0px;padding-left: 0px;padding-right: 0px;"
                                name="status" class="form-control invisible">
                            <button type="submit" class="btn btn-outline-warning float-right"
                                style="margin-right: 8px">Message non traité</button>
                        </form>
                        Article ajouté le <?php echo e(date('j M Y', strtotime($product->updated_at))); ?>

                    </div>
                    <div class="card-body">
                        <div class="row" style="margin-top: -35px">
                            <div class="col-lg-5">
                                <div class="faq-content mt-45">
                                    <div class="about-accordion">
                                        <div class="accordion" id="accordionExample">
                                            <div class="card">
                                                <div class="card-header" id="headingOne">
                                                    <a href="#" data-toggle="collapse" data-target="#collapseOne"
                                                        aria-expanded="true"
                                                        aria-controls="collapseOne"><?php echo e($product->title); ?>

                                                    </a>
                                                </div>

                                                <p class="text-justify" style="font-size: 12px; margin-top: 5px">
                                                    Description: <?php echo e($product->description); ?>

                                                </p>

                                                <p class="text-justify" style="font-size: 12px; margin-top: 5px">
                                                    Prix : <?php echo e($product->price); ?>

                                                </p>
                                                <ul class="list-group" style="margin-top: 8px">
                                                    <li class="list-group-item active">Informations du client</li>
                                                    <li class="list-group-item">Nom : <?php echo e($product->name); ?> </li>
                                                    <li class="list-group-item">Email: <?php echo e($product->email); ?></li>
                                                    <li class="list-group-item">Contact: <?php echo e($product->contact); ?></li>
                                                </ul>
                                            </div>
                                            </form>
                                        </div>
                                    </div> <!-- faq accordion -->
                                </div> <!-- faq content -->
                            </div>
                            <div class="col-lg-7">
                                <div class="about-image mt-50">
                                    <img src="<?php echo e(URL::asset('images/' . $product->image_path)); ?>" alt="about">
                                </div> <!-- faq image -->
                            </div>
                        </div> <!-- row -->
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> <!-- container -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\LaravelBIFM\Dynamics\resources\views/selling/index.blade.php ENDPATH**/ ?>