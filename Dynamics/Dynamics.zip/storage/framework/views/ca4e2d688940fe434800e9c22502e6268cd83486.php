<?php $__env->startSection('content'); ?>

    <section id="about" class="about-area">
            <div style="margin:75px">
                <h2 style="margin-top: 115px">
                    <?php echo e($post->title); ?>

                </h2>

                <div style="margin-top:15px">
                    <div class="about-image mt-70">
                        <img src="<?php echo e(URL::asset('images/' . $post->image_path)); ?>" alt="about">
                    </div> <!-- faq image -->
                </div>

                <div>
                    <p class="text-justify" style="font-size: 19px; margin-top: 15px">
                        <?php echo e($post->description); ?>

                    </p>
                </div>
            </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\LaravelBIFM\Dynamics\resources\views/news/show.blade.php ENDPATH**/ ?>