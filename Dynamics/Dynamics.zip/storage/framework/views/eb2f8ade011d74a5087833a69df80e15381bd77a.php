<?php $__env->startSection('content'); ?>

<section id="about" class="about-area">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="about-image mt-70">
                        <img src="<?php echo e(URL::asset('images/pw.jpg')); ?>" alt="about">
                    </div> <!-- faq image -->
                </div>
                <div class="col">
                    <div class="faq-content mt-55">
                        <h2>
                            <?php echo e($post->title); ?>

                        </h2>
                        <span>
                            Par <span class="font-weight-bold font-italic"> <?php echo e($post->user->name); ?> de BIFM Technology
                            </span>, ajouté le <?php echo e(date('jj M Y', strtotime($post->updated_at))); ?>

                        </span>
                        <p class="text-justify" style="font-size: 19px; margin-top: 15px">
                            <?php echo e($post->description); ?>

                        </p>

                        <a href="/Actualite/<?php echo e($post->slug); ?>" class="btn btn-primary btn-lg text-uppercase"
                            style="margin-top: 35px">Plus de
                            détails</a>
                    </div>
                </div>
            </div>
        </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\LaravelBIFM\Dynamics\resources\views/news/Nouveau.blade.php ENDPATH**/ ?>